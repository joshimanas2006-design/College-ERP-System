package com.collegeerp.collegeerp.repository;

import com.collegeerp.collegeerp.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {
}