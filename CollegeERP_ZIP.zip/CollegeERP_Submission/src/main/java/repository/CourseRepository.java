package com.collegeerp.collegeerp.repository;

import com.collegeerp.collegeerp.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long> {
}
