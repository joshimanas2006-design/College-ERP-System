package com.collegeerp.collegeerp.repository;

import com.collegeerp.collegeerp.entity.Faculty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacultyRepository extends JpaRepository<Faculty, Long> {
}
