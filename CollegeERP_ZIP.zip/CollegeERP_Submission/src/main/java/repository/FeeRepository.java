package com.collegeerp.collegeerp.repository;

import com.collegeerp.collegeerp.entity.Fee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeeRepository extends JpaRepository<Fee, Long> {
}