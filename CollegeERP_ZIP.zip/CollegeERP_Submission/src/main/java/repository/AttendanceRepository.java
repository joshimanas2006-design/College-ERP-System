package com.collegeerp.collegeerp.repository;

import com.collegeerp.collegeerp.entity.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
}