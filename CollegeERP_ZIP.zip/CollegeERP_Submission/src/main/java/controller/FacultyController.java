package com.collegeerp.collegeerp.controller;

import com.collegeerp.collegeerp.entity.Faculty;
import com.collegeerp.collegeerp.repository.FacultyRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/faculty")
public class FacultyController {

    private final FacultyRepository facultyRepository;

    public FacultyController(FacultyRepository facultyRepository) {
        this.facultyRepository = facultyRepository;
    }

    // Display all faculty
    @GetMapping
    public String listFaculty(Model model) {
        model.addAttribute("facultyList", facultyRepository.findAll());
        return "faculty";
    }

    // Show Add Faculty form
    @GetMapping("/new")
    public String showFacultyForm(Model model) {
        model.addAttribute("faculty", new Faculty());
        return "faculty-form";
    }

    // Save or Update Faculty
    @PostMapping("/save")
    public String saveFaculty(@ModelAttribute Faculty faculty) {
        facultyRepository.save(faculty);
        return "redirect:/faculty";
    }

    // Show Edit Faculty form
    @GetMapping("/edit/{id}")
    public String editFaculty(@PathVariable Long id, Model model) {

        Faculty faculty = facultyRepository.findById(id).orElse(null);

        if (faculty == null) {
            return "redirect:/faculty";
        }

        model.addAttribute("faculty", faculty);
        return "faculty-form";
    }

    // Delete Faculty
    @GetMapping("/delete/{id}")
    public String deleteFaculty(@PathVariable Long id) {
        facultyRepository.deleteById(id);
        return "redirect:/faculty";
    }
}