package com.collegeerp.collegeerp.controller;

import com.collegeerp.collegeerp.repository.AttendanceRepository;
import com.collegeerp.collegeerp.repository.CourseRepository;
import com.collegeerp.collegeerp.repository.FacultyRepository;
import com.collegeerp.collegeerp.repository.FeeRepository;
import com.collegeerp.collegeerp.repository.ReportRepository;
import com.collegeerp.collegeerp.repository.StudentRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class HomeController {

    private final StudentRepository studentRepository;
    private final FacultyRepository facultyRepository;
    private final CourseRepository courseRepository;
    private final AttendanceRepository attendanceRepository;
    private final FeeRepository feeRepository;
    private final ReportRepository reportRepository;

    public HomeController(
            StudentRepository studentRepository,
            FacultyRepository facultyRepository,
            CourseRepository courseRepository,
            AttendanceRepository attendanceRepository,
            FeeRepository feeRepository,
            ReportRepository reportRepository) {

        this.studentRepository = studentRepository;
        this.facultyRepository = facultyRepository;
        this.courseRepository = courseRepository;
        this.attendanceRepository = attendanceRepository;
        this.feeRepository = feeRepository;
        this.reportRepository = reportRepository;
    }

    @GetMapping("/api/dashboard/counts")
    public Map<String, Long> getDashboardCounts() {

        return Map.of(
                "students", studentRepository.count(),
                "faculty", facultyRepository.count(),
                "courses", courseRepository.count(),
                "attendance", attendanceRepository.count(),
                "fees", feeRepository.count(),
                "reports", reportRepository.count()
        );
    }
}