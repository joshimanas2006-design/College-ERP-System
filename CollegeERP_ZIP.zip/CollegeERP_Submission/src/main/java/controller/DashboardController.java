package com.collegeerp.collegeerp.controller;

import com.collegeerp.collegeerp.repository.CourseRepository;
import com.collegeerp.collegeerp.repository.FacultyRepository;
import com.collegeerp.collegeerp.repository.StudentRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final StudentRepository studentRepository;
    private final FacultyRepository facultyRepository;
    private final CourseRepository courseRepository;

    public DashboardController(StudentRepository studentRepository,
                               FacultyRepository facultyRepository,
                               CourseRepository courseRepository) {
        this.studentRepository = studentRepository;
        this.facultyRepository = facultyRepository;
        this.courseRepository = courseRepository;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {

        model.addAttribute("studentCount", studentRepository.count());
        model.addAttribute("facultyCount", facultyRepository.count());
        model.addAttribute("courseCount", courseRepository.count());

        return "dashboard";
    }
}