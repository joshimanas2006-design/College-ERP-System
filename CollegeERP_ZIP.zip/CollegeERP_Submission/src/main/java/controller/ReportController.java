package com.collegeerp.collegeerp.controller;

import com.collegeerp.collegeerp.entity.Report;
import com.collegeerp.collegeerp.service.ReportService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reports")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping
    public String reports(Model model) {
        model.addAttribute("reports", reportService.getAllReports());
        return "reports";
    }

    @GetMapping("/add")
    public String addReport(Model model) {
        model.addAttribute("report", new Report());
        return "report-form";
    }

    @PostMapping("/save")
    public String saveReport(@ModelAttribute Report report) {
        reportService.saveReport(report);
        return "redirect:/reports";
    }

    @GetMapping("/edit/{id}")
    public String editReport(@PathVariable Long id, Model model) {
        model.addAttribute("report", reportService.getReportById(id));
        return "report-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteReport(@PathVariable Long id) {
        reportService.deleteReport(id);
        return "redirect:/reports";
    }
}