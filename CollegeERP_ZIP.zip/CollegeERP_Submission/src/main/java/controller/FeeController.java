package com.collegeerp.collegeerp.controller;

import com.collegeerp.collegeerp.entity.Fee;
import com.collegeerp.collegeerp.service.FeeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/fees")
public class FeeController {

    private final FeeService feeService;

    public FeeController(FeeService feeService) {
        this.feeService = feeService;
    }

    @GetMapping
    public String fees(Model model) {
        model.addAttribute("fees", feeService.getAllFees());
        return "fees";
    }

    @GetMapping("/add")
    public String addFee(Model model) {
        model.addAttribute("fee", new Fee());
        return "fee-form";
    }

    @PostMapping("/save")
    public String saveFee(@ModelAttribute Fee fee) {
        feeService.saveFee(fee);
        return "redirect:/fees";
    }

    @GetMapping("/edit/{id}")
    public String editFee(@PathVariable Long id, Model model) {
        model.addAttribute("fee", feeService.getFeeById(id));
        return "fee-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteFee(@PathVariable Long id) {
        feeService.deleteFee(id);
        return "redirect:/fees";
    }
}