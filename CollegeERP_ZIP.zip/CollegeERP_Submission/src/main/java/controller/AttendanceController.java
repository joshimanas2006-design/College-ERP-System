package com.collegeerp.collegeerp.controller;

import com.collegeerp.collegeerp.entity.Attendance;
import com.collegeerp.collegeerp.service.AttendanceService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    @GetMapping
    public String attendance(Model model) {
        model.addAttribute("attendanceList",
                attendanceService.getAllAttendance());

        return "attendance";
    }

    @GetMapping("/add")
    public String addAttendance(Model model) {
        model.addAttribute("attendance", new Attendance());

        return "attendance-form";
    }

    @PostMapping("/save")
    public String saveAttendance(
            @ModelAttribute Attendance attendance) {

        attendanceService.saveAttendance(attendance);

        return "redirect:/attendance";
    }

    @GetMapping("/edit/{id}")
    public String editAttendance(
            @PathVariable Long id,
            Model model) {

        model.addAttribute(
                "attendance",
                attendanceService.getAttendanceById(id)
        );

        return "attendance-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteAttendance(
            @PathVariable Long id) {

        attendanceService.deleteAttendance(id);

        return "redirect:/attendance";
    }
}