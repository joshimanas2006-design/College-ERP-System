package com.collegeerp.collegeerp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeErpApplication {

    public static void main(String[] args) {
        SpringApplication.run(CollegeErpApplication.class, args);
    }

}
